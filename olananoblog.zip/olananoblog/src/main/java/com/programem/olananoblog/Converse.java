package com.programem.olananoblog;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity /** indica que o Banco de Dados deve criar uma tabela para esse objeto */
public class Converse {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    String titulo;

    String texto;

    public void setId(Integer id){
        this.id = id;
    }

    public void setTitulo(String titulo){
        this.titulo = titulo;
    }

    public void setTexto(String texto){
        this.texto = texto;
    }

    public Integer getId(){
        return this.id;
    }

    public String getTitulo(){
        return this.titulo;
    }

    public String getTexto(){
        return this.texto;
    }

}