package com.programem.olananoblog;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/converse")
public class ConverseController {

    @Autowired
    private ConverseRepository converseRepository;
    private Lista lista = new Lista();

    @GetMapping("/")
    public String converseForm(){
      return "converseForm";
    }

    @PostMapping(path="/insere") // Map ONLY POST Requests
    public @ResponseBody String addNewConverse (
         @RequestParam String titulo
        ,@RequestParam String texto
        ) {

            Converse c = new Converse();

            c.setTitulo(titulo);
            c.setTexto(texto);
            
            converseRepository.save(c);

            return titulo+" "+texto;
    }

    @GetMapping(path="/lista")
    public @ResponseBody String getAllConverse() {

      Iterable<Converse> resultado = converseRepository.findAll();
      
      return lista.listaConverse(resultado);
    }

    @GetMapping(path="/updateForm")
    public String updateForm(){
      return "updateForm";
    }

    @PostMapping(path="/update")
    public @ResponseBody String updateConverse(@RequestParam String texto, @RequestParam Integer id) {
        Optional<Converse> o = converseRepository.findById(id);

        if(o.isPresent()){
          Converse t = o.get();
          t.setTexto(texto);
          converseRepository.save(t);
        }

      return "updateResposta";
    }

    
  }