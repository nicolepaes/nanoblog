package com.programem.olananoblog;

public class Lista {
    String listaConverse(Iterable<Converse> lista){
        String html = "";

        for(Converse c : lista){
            html = html +
            "<h1>"+c.getTitulo()+"</h1>"+
            c.getTexto()+"<br>"+
            "<br>"
            ;
        }
        return html;
    }
}