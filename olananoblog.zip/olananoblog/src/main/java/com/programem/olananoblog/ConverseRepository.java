package com.programem.olananoblog;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

public interface ConverseRepository extends CrudRepository<Converse, Integer> {

    @Query(
    value = "SELECT * FROM converse WHERE converse.texto >= :texto", 
     nativeQuery = true)
    Iterable<Converse> findConverse(@Param("") String texto );

}